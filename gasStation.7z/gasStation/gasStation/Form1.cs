﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gasStation
{
    public partial class Form1 : Form
    {
        private double animationPercent1 = 0.05;
        private double animationPercent2 = 0.05;
        private double animationPercent3 = 0.05;

        private Image originalPumpImage = null;

      
    

        public Form1()
        {
            InitializeComponent();
            originalPumpImage = pictureBox3.Image;
        }


        private Image RecolorImage(PictureBox pictureBox, double percentAnimation)
        {
            Bitmap original = new Bitmap(pictureBox.Image, pictureBox.Width, pictureBox.Height);
            using (Graphics g = Graphics.FromImage(original))
            {
                ImageAttributes imageAttributes = CreateRecolorTable();
                Rectangle coloredRectangle = CreateColoredRectangle(pictureBox, percentAnimation);
                Bitmap croppedImage = this.Crop(original, coloredRectangle);

                g.DrawImage(

                        croppedImage,
                        coloredRectangle,
                        0, 0, coloredRectangle.Width, coloredRectangle.Height,
                        GraphicsUnit.Pixel,
                        imageAttributes
                );
                return original;
            }
        }

        private static ImageAttributes CreateRecolorTable()
        {
            ImageAttributes imageAttributes = new ImageAttributes();
            ColorMap colorMap = new ColorMap();
            colorMap.OldColor = Color.FromArgb(51, 51, 51);
            colorMap.NewColor = Color.FromArgb(0, 255, 0);
            ColorMap[] remapTable = { colorMap };

            imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap);
            return imageAttributes;

        }



        private static Rectangle CreateColoredRectangle(PictureBox pictureBox, double percentAnimation)
        {
            int heightAnimation = (int)(percentAnimation * pictureBox.Height);

            Rectangle coloredRectangle = new Rectangle(
new Point(0, pictureBox.Height - heightAnimation),
new Size(pictureBox.Width, heightAnimation)
            );
            
        return coloredRectangle;

        }


        private Bitmap Crop(Bitmap original, Rectangle coloredRectangle)
        {
            Bitmap cropped = new Bitmap(coloredRectangle.Width, coloredRectangle.Height);
            using (Graphics g = Graphics.FromImage(cropped))
            {
                g.DrawImage(original, -coloredRectangle.X, -coloredRectangle.Y);
                return cropped;

            }
        }

           private void timer1_Tick(object sender, EventArgs e)
        {

            pictureBox1.Image = RecolorImage(pictureBox1, animationPercent1); 
            if (animationPercent1 >= 1)
            {
                timer1.Stop();
                animationPercent1 = 0.05;
                pictureBox1.Image = originalPumpImage;
                MessageBox.Show("Готово - колонка 1!");
            }
                
            
            animationPercent1 += 0.05;

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            pictureBox2.Image = RecolorImage(pictureBox2, animationPercent2);
            if (animationPercent1 >= 1)
            {
                timer2.Stop();
                animationPercent2 = 0.05;
                pictureBox2.Image = originalPumpImage;
                MessageBox.Show("Готово - колонка 1!");
            }


            animationPercent1 += 0.05;

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
          
        }



        private void btnLoad_Click(object sender, EventArgs e)
        {
            timer1.Tick += timer1_Tick;
            timer1.Interval = 1000;

            timer1.Start();
          
        }

    }
}
